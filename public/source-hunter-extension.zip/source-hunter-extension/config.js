// Where the Source Hunter app runs.
self.APP = "https://source-hunter.vercel.app";
