Source Hunter extension
=======================
1. Open chrome://extensions
2. Turn on "Developer mode" (top right)
3. Click "Load unpacked" and choose this folder (the one containing manifest.json)

Use it: highlight a claim on any page and click "Trace it", or click the toolbar icon with nothing selected to scan the page (Claim Radar).
App: https://source-hunter.vercel.app
